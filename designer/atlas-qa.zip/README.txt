Upload into QA Inspector. Component hover, page scan, site scan. Crawl starts #/overview, follows local links, max 12 pages.
